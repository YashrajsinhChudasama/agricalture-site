﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Data.Sql;
namespace agricutural_project.admin
{
    public partial class adminlogin : System.Web.UI.Page
    {
        SqlConnection con=new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=D:\yashrajsinh\Agriculture project\agricutural project\agricutural project\App_Data\agriculture .mdf;Integrated Security=True;User Instance=True");
        
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }
        
        
      
        protected void Button1_Click1(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                String query = "SELECT * FROM admin_login WHERE unm= '" + TextBox1.Text + "' and pass='" + TextBox2.Text + "' ";
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    Response.Redirect("dashboard.aspx");
                }
                else
                {
                    Response.Write("not");

                }
                con.Close();
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);

            }
            
        }
    }
}