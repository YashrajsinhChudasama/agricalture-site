﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace agricutural_project.admin
{
    public partial class dashboard : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            tech_pan.Visible = false;
            tan_pan.Visible = false;
            con.Visible = false;
        }

     
        protected void Button1_Click(object sender, EventArgs e)
        {
            tech_pan.Visible = true;
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            tan_pan.Visible = true;
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            con.Visible = true;
        }

        
     
    }
}