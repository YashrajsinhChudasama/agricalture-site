﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace signal
{
    public partial class Form1 : Form
    {
        int i;
        public Form1()
        {
            InitializeComponent();
        }

        private void ovalShape4_Click(object sender, EventArgs e)
       {

            i++;
            if (i == 1)
            {
                ovalShape1.Visible = true;
                ovalShape2.Visible = false;
                ovalShape3.Visible = false;

            }

            else if (i == 2)
            {
                ovalShape1.Visible = false;
                ovalShape2.Visible = true;
                ovalShape3.Visible = false;
            }

            else if (i == 3)
            {
                ovalShape1.Visible = false;
                ovalShape2.Visible = false;
                ovalShape3.Visible = true;

                i = 0;

            }
        }
    }
}
