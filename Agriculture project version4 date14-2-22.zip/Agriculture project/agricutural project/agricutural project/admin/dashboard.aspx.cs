﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
namespace agricutural_project.admin
{
    public partial class dashboard : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            tech_pan.Visible = false;
            tan_pan.Visible = false;
            con.Visible = false;
        }
        SqlConnection conn=new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=D:\yashrajsinh\Agriculture project\agricutural project\agricutural project\App_Data\agriculture .mdf;Integrated Security=True;User Instance=True");
     
        protected void Button1_Click(object sender, EventArgs e)
        {
            tech_pan.Visible = true;
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            tan_pan.Visible = true;
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            con.Visible = true;
        }

        protected void save_Click(object sender, EventArgs e)
        {
            Response.Write("<script>alert('Data inserted successfully')</script>");
        }

        protected void save_Click1(object sender, EventArgs e)
        {
            if (!FileUpload1.HasFile)
            {
                Label11.Visible = true;
                Label11.Text = "Please, Select image";
            }
            else
            {
                int length = FileUpload1.PostedFile.ContentLength;
                byte[] pic = new byte[length];
                FileUpload1.PostedFile.InputStream.Read(pic, 0, length);
                try {
                    conn.Open();
                    string query = "INSERT INTO tech_tab(image,) VALUE('" + pic + "')";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    Label11.Visible = true;
                    Label11.Text = "done";
                    conn.Close();
                }
                catch (Exception ex)
                {
                    Response.Write(ex.Message); 
                }
            }
        }
        
        protected void save2_Click1(object sender, EventArgs e)
        {
            Response.Write("tran");
        }
        
     
    }
}