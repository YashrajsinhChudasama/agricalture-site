﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Collections;
using System.IO;
namespace agricutural_project.admin
{
    public partial class dashboard : System.Web.UI.Page
    {
        
        SqlConnection conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=D:\yashrajsinh\agriculture site project\ag2\Agriculture project\agricutural project\agricutural project\App_Data\agriculture.mdf;Integrated Security=True;User Instance=True");
        protected void Page_Load(object sender, EventArgs e)
        {
           try
            {
                
                string query1 = "SELECT * FROM admintech";
                        
                SqlDataAdapter da = new SqlDataAdapter(query1, conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                Repeater1.DataSource = dt;
                Repeater1.DataBind();
                tech_count.Text = "Technology:                         " + dt.Rows.Count.ToString();
                
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }

           try
           {

               string query2 = "SELECT * FROM admin_ten";

               SqlDataAdapter da2 = new SqlDataAdapter(query2, conn);
               DataTable dt2 = new DataTable();
               da2.Fill(dt2);
               Repeater2.DataSource = dt2;
               Repeater2.DataBind();
               tran_count.Text = "Tranning:                         " + dt2.Rows.Count.ToString();

           }
           catch (Exception ex)
           {
               Response.Write(ex.Message);
           }
          
            
            
        }
     
     
        

        protected void save_Click1(object sender, EventArgs e)
        {
            string filename = Path.GetFileName(FileUpload1.FileName);
            string path = Server.MapPath("/products/");
            Random r = new Random();
            string new1 = r.Next().ToString();
            string extension = System.IO.Path.GetExtension(FileUpload1.PostedFile.FileName);
            string final_path =path +new1 + extension;
            FileUpload1.SaveAs(final_path);
            string dbpath = @"\products\" + new1 + extension; 
            //FileUpload1.SaveAs(Server.MapPath("~/images/" + filename));
             
            /*HttpPostedFile postedfile = FileUpload1.PostedFile;
            string filename = Path.GetFileName(postedfile.FileName);
            string fileextension = Path.GetExtension(filename);
            Stream stream = postedfile.InputStream;
            BinaryReader binaryreader = new BinaryReader(stream);
            byte[] bytes = binaryreader.ReadByte((int)stream.Length);

            */
            conn.Open();


            
            string query = "Insert into admintech(imagename,imagepath,tech_name,tech_disc) VALUES('" + filename + "','" + dbpath + "','" + TextBox1.Text + "','" + TextBox2.Text + "')";
            SqlCommand cmd = new SqlCommand(query,conn);
            cmd.ExecuteNonQuery();
            conn.Close();
            
            
        }
        
        protected void save2_Click1(object sender, EventArgs e)
        {
            string filename = Path.GetFileName(FileUpload2.FileName);
            string path = Server.MapPath("/products/");
            Random r = new Random();
            string new2 = r.Next().ToString();
            string extension = System.IO.Path.GetExtension(FileUpload2.PostedFile.FileName);
            string final_path = path + new2 + extension;
            FileUpload2.SaveAs(final_path);
            string dbpath = @"\products\" + new2 + extension; 

            /*
            string filename = Path.GetFileName(FileUpload2.FileName);
            string path = Server.MapPath("/products/");
            Random r = new Random();
            string new2 = r.Next().ToString();
            string extension = System.IO.Path.GetExtension(FileUpload2.PostedFile.FileName);
            string final_path = path + new2 + extension;
            FileUpload2.SaveAs(final_path);
            string dbpath = @"\products\" + new2 + extension; 
            */
             //FileUpload1.SaveAs(Server.MapPath("~/images/" + filename));
            conn.Open();


            string query = "Insert into admin_ten(imagename,imagepath,ten_name,ten_disc) VALUES('" + filename + "','" + dbpath + "','" + TextBox3.Text + "','" + TextBox4.Text + "')";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.ExecuteNonQuery();
            conn.Close();
            Response.Write("done");
        }
        
     
    }
}