﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data;

namespace agricutural_project
{
    public partial class home : System.Web.UI.Page
    {SqlConnection conn=new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=D:\yashrajsinh\agriculture site project\ag2\Agriculture project\agricutural project\agricutural project\App_Data\agriculture.mdf;Integrated Security=True;User Instance=True");
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {

                string query1 = "SELECT * FROM admintech";

                SqlDataAdapter da = new SqlDataAdapter(query1, conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
              
                Repeater3.DataSource = dt;
                Repeater3.DataBind();


            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
            try
            {

                string query2 = "SELECT * FROM admin_ten";

                SqlDataAdapter da = new SqlDataAdapter(query2, conn);
                DataTable dt = new DataTable();
                da.Fill(dt);

                Repeater4.DataSource = dt;
                Repeater4.DataBind();


            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }

        }
    }
}